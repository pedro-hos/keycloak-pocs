package br.com.pedrohos.keycloakspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakSpringbootApplication.class, args);
	}

}
